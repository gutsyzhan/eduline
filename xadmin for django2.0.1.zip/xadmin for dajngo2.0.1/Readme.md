﻿# Xadmin for Django2.0.1

- 在Xadmin for Django 2.0的基础上修改部分bug, 以及必要的改动！

- 此版本主要是为了在线教育网站项目而修改的，亲测Python3.6.4+Django2.0.1运行无Bug！ 
- 如果你在运行过程中出现了Bug,可能是由于第三方库的版本问题，请更新版本后再次运行！
## 运行要求库及版本号
```
Package                          Version
-------------------------------- --------
confusable-homoglyphs            3.1.1
diff-match-patch                 20121119
Django                           2.0.1
django-crispy-forms              1.7.2
django-crispy-forms-registration 0.1.3
django-formtools                 2.1
django-import-export             1.0.1
django-registration              2.4.1
django-reversion                 3.0.0
et-xmlfile                       1.0.1
future                           0.16.0
httplib2                         0.11.3
jdcal                            1.4
mysqlclient                      1.3.13
odfpy                            1.3.6
openpyxl                         2.5.4
Pillow                           5.2.0
pip                              18.0
pytz                             2018.5
PyYAML                           3.13
setuptools                       40.0.0
six                              1.11.0
tablib                           0.12.1
unicodecsv                       0.14.1
wheel                            0.31.1
xlrd                             1.1.0
xlwt                             1.3.0
```
注意：不能低于所列版本号，不过最新版本可能也会出问题，到时候请大家及时在笔记底下留言！

- 此版本仅用作学习交流之用，勿作他途！


